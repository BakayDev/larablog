<?php

use App\Http\Controllers\Admin\CategoryController;
use App\Http\Controllers\Admin\PostController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

//Route::middleware('auth:api')->get('/user', function (Request $request) {
//    return $request->user();
//});

Route::group([
    'as' => 'api_',
    'middleware' => []], function () {


   // Route::post('/upload-image', 'ImageController@upload')->name('upload_image');

    Route::put('/category/status', [CategoryController::class, 'updateStatus'])->name('category_update_status');
   // Route::put('/category/status', 'Admin\CategoryController@updateStatus')->name('category_update_status');

    Route::put('/category/is-feature',  [CategoryController::class, 'updateIsFeature'])->name('category_update_is_feature');
    //Route::put('/category/is-feature', 'Admin\CategoryController@updateIsFeature')->name('category_update_is_feature');

    Route::put('/posts/status',  [PostController::class, 'updateStatus'])->name('post_update_status');
   // Route::put('/posts/status', 'Admin\PostController@updateStatus')->name('post_update_status');

    Route::put('/users/status',  [CategoryController::class, 'updateStatus'])->name('user_update_status');
  //  Route::put('/users/status', 'Admin\UserController@updateStatus')->name('user_update_status');


    Route::put('/users/role',  [CategoryController::class, 'updateRole'])->name('user_update_role');
  //  Route::put('/users/role', 'Admin\UserController@updateRole')->name('user_update_role');


    Route::put('/languages/default',  [CategoryController::class, 'setDefault'])->name('language_set_default');

   // Route::put('/languages/default', 'Admin\LanguageController@setDefault')->name('language_set_default');


    // Route::post('/user/reset-password', 'Frontend\ResetPasswordController@sendMail')->name('user_forgot_password');
});


Route::group([
    'prefix' => 'app',
    'namespace' => 'API',
    'as' => 'api_app_',
    'middleware' => []], function ()   {



    Route::get('/posts/inspiration', [PostController::class, 'postInspiration']);
    // Route::get('/posts/inspiration', 'PostController@postInspiration');

});
