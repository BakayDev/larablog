<?php

use App\Http\Controllers\Admin\CategoryController;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\LanguageController;
use App\Http\Controllers\Admin\PostController;
use App\Http\Controllers\Admin\SettingController;
use App\Http\Controllers\Admin\UsersController;
use App\Http\Controllers\Frontend\HomeController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Auth::routes();

//Route::get('/home', [HomeController::class, 'index'])->name('home');

//Route::get('/', [HomeController::class, 'index'])->name('home');

//Route::get('/language/{locale}', [HomeController::class, 'changeLanguage'])->name('change.language');
//Route::get('/language/{locale}', 'HomeController@changeLanguage')->name('change_language');



//Route::get('/blog/all',  [HomeController::class, 'list'])->name('post.list.all');
//Route::get('/blog/all', 'PostController@list')->name('post_list_all');

//Route::get('/blog/{cat_slug}', [HomeController::class, 'list'])->where('cat_slug', '[a-zA-Z0-9-_]+')->name('post.list');
// Route::get('/blog/{cat_slug}', 'PostController@list')->where('cat_slug', '[a-zA-Z0-9-_]+')->name('post_list');




// Route::get('/post/{slug}-{id}', 'PostController@detail')
//    ->where('slug', '[a-zA-Z0-9-_]+')
//    ->where('id', '[0-9]+')->name('post_detail');



Route::group([
    'namespace' => 'Frontend',
    'middleware' => []], function () {
    Route::get('/post/{slug}-{id}', [\App\Http\Controllers\Frontend\PostController::class, 'detail'])
        ->where('slug', '[a-zA-Z0-9-_]+')
        ->where('id', '[0-9]+')->name('post.detail');

    Route::get('/', [HomeController::class, 'index'])->name('home');
    //Route::get('/', 'HomeController@index')->name('home');

    Route::get('/blog/all', [\App\Http\Controllers\Frontend\PostController::class, 'list'])->name('post.list.all');

    Route::get('/language/{locale}', [HomeController::class, 'changeLanguage'])->name('change.language');
   // Route::get('/language/{locale}', 'HomeController@changeLanguage')->name('change_language');

/*


    Route::get('/blog/all', 'PostController@list')->name('post_list_all');
    Route::get('/blog/{cat_slug}', 'PostController@list')->where('cat_slug', '[a-zA-Z0-9-_]+')->name('post_list');
    Route::get('/post/{slug}-{id}', 'PostController@detail')
        ->where('slug', '[a-zA-Z0-9-_]+')
        ->where('id', '[0-9]+')->name('post_detail');

    Route::get('/page/contact', 'HomeController@pageContact')->name('page_contact');
    Route::post('/page/contact', 'HomeController@sendContact')->name('page_contact_send');

    Route::get('/page/landing/{page_number}', 'HomeController@pageLanding')->name('page_landing');

    Route::get('/user/profile', 'UserController@pageProfile')->name('user_profile')->middleware('auth');
    Route::put('/user/profile', 'UserController@updateProfile')->name('user_profile_update')->middleware('auth');
    Route::put('/user/profile/password', 'UserController@updatePassword')->name('user_password_update')->middleware('auth');
    Route::get('/user/reset-password', 'UserController@pageResetPassword')->name('user_reset_password');
    Route::put('/user/reset-password', 'ResetPasswordController@reset')->name('user_update_password');
    Route::get('/auth/{social}', 'SocialAuthController@redirect')->name('login_social');
    Route::get('/auth/{social}/callback', 'SocialAuthController@callback')->name('login_social_callback');*/
});

Route::group(
    [
        'prefix' => 'admincp',
        'as' => 'admin.',
       // 'namespace' => 'Admin',
      //'middleware' => ['auth', 'can:admin-panel'],
    ],
    function () {
       //  Route::post('/ajax/upload/image', 'UploadController@image')->name('ajax.upload.image');

        Route::get('/', [DashboardController::class, 'index'])->name('dashboard');

        Route::resource('users', UsersController::class);

        Route::get('/category/{type}', [CategoryController::class, 'list'])->name('category.list');
        //Route::get('/category/{type}', 'CategoryController@list')->name('category_list');
        Route::post('/category', [CategoryController::class, 'create'])->name('category.create');
        //Route::post('/category', 'CategoryController@create')->name('category_create');
        Route::put('/category', [CategoryController::class, 'update'])->name('category.update');
        //Route::put('/category', 'CategoryController@update')->name('category_update');
        Route::delete('/category/{id}', [CategoryController::class, 'destroy'])->name('category.delete');
        //Route::delete('/category/{id}', 'CategoryController@destroy')->name('category_delete');




        Route::get('/blog', [PostController::class, 'list'])->name('post.list.blog');
       // Route::get('/blog', 'PostController@list')->name('post_list_blog');
        Route::get('/pages', [PostController::class, 'list'])->name('post.list.page');
        // Route::get('/pages', 'PostController@list')->name('post_list_page');

        Route::get('/posts/add/{type}', [PostController::class, 'pageCreate'])->name('post.add');
        //Route::get('/posts/add/{type}', 'PostController@pageCreate')->name('post_add');


        Route::get('/posts/{id}', [PostController::class, 'pageCreate'])->name('post.edit');
        //Route::get('/posts/{id}', 'PostController@pageCreate')->name('post_edit');

        Route::post('/posts', [PostController::class, 'create'])->name('post.create');
        //Route::post('/posts', 'PostController@create')->name('post_create');

        Route::put('/posts', [PostController::class, 'update'])->name('post.update');
        //Route::put('/posts', 'PostController@update')->name('post_update');

        Route::delete('/posts/{id}', [PostController::class, 'destroy'])->name('post.delete');
        //Route::delete('/posts/{id}', 'PostController@destroy')->name('post_delete');

        // $Route::get('/users', 'UserController@list')->name('user_list');
        Route::get('/users', [UsersController::class, 'list'])->name('user.list');


        Route::get('/settings', [SettingController::class, 'index'])->name('settings');
        //Route::get('/settings', 'SettingController@index')->name('settings');
        Route::post('/settings', [SettingController::class, 'store'])->name('setting.create');
       // Route::post('/settings', 'SettingController@store')->name('setting_create');

        Route::get('/settings/language', [SettingController::class, 'pageLanguage'])->name('settings.language');
       // Route::get('/settings/language', 'SettingController@pageLanguage')->name('settings_language');

        Route::get('/settings/translation', [SettingController::class, 'pageTranslation'])->name('settings.translation');
        //Route::get('/settings/translation', 'SettingController@pageTranslation')->name('settings_translation');

        Route::put('/settings/language/status/{code}', [LanguageController::class, 'updateStatus'])->name('settings.language.status');
        //Route::put('/settings/language/status/{code}', 'LanguageController@updateStatus')->name('settings_language_status');


        Route::put('/settings/language/default', [LanguageController::class, 'updateStatus'])->name('settings_language_default');
       // Route::put('/settings/language/default', 'LanguageController@updateStatus')->name('settings_language_default');

    }
);
