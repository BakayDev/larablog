@extends('frontend.layouts.template')
@section('main')
    <main id="main" class="site-main">

        <div class="news">
            <div class="container">
                <h2 class="news__title title title--more">
                    {{__('Related stories')}}
                    <a href="{{route('post.list.all')}}" title="{{__('View more')}}">
                        {{__('View more')}}
                        <svg xmlns="http://www.w3.org/2000/svg" width="6" height="10" viewBox="0 0 6 10">
                            <path fill="#23D3D3" fill-rule="nonzero" d="M5.356 4.64L.862.148A.503.503 0 1 0 .148.86l4.137 4.135L.148 9.132a.504.504 0 1 0 .715.713l4.493-4.492a.509.509 0 0 0 0-.713z"/>
                        </svg>
                    </a>
                </h2>
                <div class="news__content">
                    <div class="row">
                        @foreach($blog_posts as $post)
                            <div class="col-md-4">
                                <article class="post hover__box">
                                    <div class="post__thumb hover__box__thumb">
                                        <a title="{{$post->title}}" href="{{route('post.detail', [$post->slug, $post->id])}}"><img src="{{getImageUrl($post->thumb)}}" alt="{{$post->title}}"></a>
                                    </div>
                                    <div class="post__info">
                                        <ul class="post__category">
                                            @foreach($post['categories'] as $cat)
                                                <li><a title="{{$cat->name}}" href="{{route('post.list', $cat->slug)}}">{{$cat->name}}</a></li>
                                            @endforeach
                                        </ul>
                                        <h3 class="post__title"><a title="{{$post->title}}" href="{{route('post.detail', [$post->slug, $post->id])}}">{{$post->title}}</a></h3>
                                    </div>
                                </article>
                            </div>
                        @endforeach

                    </div>
                </div>
            </div>
        </div><!-- .news -->
    </main><!-- .site-main -->
@stop
