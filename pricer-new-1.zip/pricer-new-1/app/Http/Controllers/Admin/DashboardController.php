<?php

namespace App\Http\Controllers\Admin;


use App\Http\Controllers\Controller;
use App\Models\User;

class DashboardController extends Controller
{
    public function index()
    {
        $count_users = User::query()
            ->count();

        return view('admin.dashboard.index', [
            'count_users' => $count_users,
        ]);
    }
}
