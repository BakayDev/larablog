<?php $__env->startSection('main'); ?>

    <div class="page-title">
        <div class="title_left">
            <h3>Posts</h3>
        </div>
        <div class="title_right">
            <div class="pull-right">
                <a class="btn btn-primary" href="<?php echo e(route('admin.post.add', $post_type)); ?>">+ Add new</a>
            </div>
        </div>
    </div>
    <div class="clearfix"></div>

    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
                <div class="x_title">
                    <?php if (! (isRoute('admin.post.list.page'))): ?>
                        <form class="row">
                            <div class="col-md-3 form-group">
                                <label>Select Categories:</label>
                                <select class="form-control" id="select_category_id" name="category_id" onchange="this.form.submit()">
                                    <option value="">All Categories</option>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($cat->id); ?>" <?php echo e(isSelected($cat->id, $filter['category_id'])); ?>><?php echo e($cat->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </form>
                    <?php endif; ?>
                    <div class="clearfix"></div>
                </div>

                <div class="x_content">

                    <table class="table table-striped table-bordered golo-datatable post_list">
                        <thead>
                        <tr>
                            <th width="3%">ID</th>
                            <th width="5%">Thumb</th>
                            <th>Title</th>
                            <?php if (! (isRoute('admin.post.list_page'))): ?>
                                <th>Category</th>
                            <?php endif; ?>
                            <th>Status</th>
                            <th width="15%">Action</th>
                        </tr>
                        </thead>
                        <tbody>

                        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($post->id); ?></td>
                                <td><img class="post_list_thumb" src="<?php echo e(getImageUrl($post->thumb)); ?>" alt="post thumb"></td>
                                <td class="row"><a href="<?php echo e(route('post.detail', [$post->slug, $post->id])); ?>" target="_blank"><?php echo e($post->title); ?></a></td>
                                <?php if (! (isRoute('admin.post.list.page'))): ?>
                                    <td>
                                        <?php $__currentLoopData = $post->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span class="category_name"><?php echo e($cat->name); ?></span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                <?php endif; ?>
                                <td><input type="checkbox" class="js-switch post_status" data-id="<?php echo e($post->id); ?>" <?php echo e(isChecked($post->status, \App\Models\Post::STATUS_ACTIVE)); ?>/></td>
                                <td>
                                    <a class="btn btn-warning btn-xs place_edit" href="<?php echo e(route('admin.post.edit', $post->id)); ?>">Edit</a>
                                    <form class="d-inline" action="<?php echo e(route('admin.post.delete', $post->id)); ?>" method="POST">
                                        <?php echo method_field('DELETE'); ?>
                                        <?php echo csrf_field(); ?>
                                        <button type="button" class="btn btn-danger btn-xs place_delete" onclick="if(confirm('Are you sure? The post that deleted can not restore!')) $(this).parent().submit();">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>


                </div>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('admin/js/page_post.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /workspace/apps/pricer-new/resources/views/admin/post/post_list.blade.php ENDPATH**/ ?>