<?php if(session('error')): ?>
    <div class="alert alert-danger" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
        <?php echo e(session('error')); ?>

    </div>
<?php endif; ?>
<?php if(session('success')): ?>
    <div class="alert alert-success" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?><?php /**PATH /workspace/apps/pricer-new/resources/views/admin/common/box-alert.blade.php ENDPATH**/ ?>