<?php $__env->startSection('main'); ?>
    <main id="main" class="site-main">

        <div class="news">
            <div class="container">
                <h2 class="news__title title title--more">
                    <?php echo e(__('Related stories')); ?>

                    <a href="<?php echo e(route('post.list.all')); ?>" title="<?php echo e(__('View more')); ?>">
                        <?php echo e(__('View more')); ?>

                        <svg xmlns="http://www.w3.org/2000/svg" width="6" height="10" viewBox="0 0 6 10">
                            <path fill="#23D3D3" fill-rule="nonzero" d="M5.356 4.64L.862.148A.503.503 0 1 0 .148.86l4.137 4.135L.148 9.132a.504.504 0 1 0 .715.713l4.493-4.492a.509.509 0 0 0 0-.713z"/>
                        </svg>
                    </a>
                </h2>
                <div class="news__content">
                    <div class="row">
                        <?php $__currentLoopData = $blog_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4">
                                <article class="post hover__box">
                                    <div class="post__thumb hover__box__thumb">
                                        <a title="<?php echo e($post->title); ?>" href="<?php echo e(route('post.detail', [$post->slug, $post->id])); ?>"><img src="<?php echo e(getImageUrl($post->thumb)); ?>" alt="<?php echo e($post->title); ?>"></a>
                                    </div>
                                    <div class="post__info">
                                        <ul class="post__category">
                                            <?php $__currentLoopData = $post['categories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><a title="<?php echo e($cat->name); ?>" href="<?php echo e(route('post.list', $cat->slug)); ?>"><?php echo e($cat->name); ?></a></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                        <h3 class="post__title"><a title="<?php echo e($post->title); ?>" href="<?php echo e(route('post.detail', [$post->slug, $post->id])); ?>"><?php echo e($post->title); ?></a></h3>
                                    </div>
                                </article>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
            </div>
        </div><!-- .news -->
    </main><!-- .site-main -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /workspace/apps/pricer-new/resources/views/frontend/home/home.blade.php ENDPATH**/ ?>