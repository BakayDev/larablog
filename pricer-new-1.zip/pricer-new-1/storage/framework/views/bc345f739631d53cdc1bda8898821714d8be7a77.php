<?php $__env->startSection('main'); ?>
    <div class="page-title">
        <div class="title_left">
            <h3>Add new</h3>
        </div>
    </div>

    <div class="clearfix"></div>

    <div class="row">
        <form action="<?php echo e(route('admin.post.create')); ?>" enctype="multipart/form-data" method="post">
            <?php if(isRoute('admin.post.edit')): ?>
                <?php echo method_field('put'); ?>
            <?php endif; ?>
            <?php echo csrf_field(); ?>

            <div class="col-md-8 col-sm-8 col-xs-12">

                <div class="x_panel">
                    <div class="x_content">

                        <ul class="nav nav-tabs bar_tabs" role="tablist">
                            <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="nav-item">
                                    <a class="nav-link <?php echo e($index !== 0 ?: "active"); ?>" id="home-tab" data-toggle="tab" href="#language_<?php echo e($language->code); ?>" role="tab" aria-controls="" aria-selected=""><?php echo e($language->name); ?></a>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>

                        <div class="tab-content">
                            <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <?php
                                    $trans = $post ? $post->translate($language->code) : [];
                                ?>
                                <div class="tab-pane fade show <?php echo e($index !== 0 ?: "active"); ?>" id="language_<?php echo e($language->code); ?>" role="tabpanel" aria-labelledby="home-tab">
                                    <div class="form-group row">
                                        <div class="col-md-12">
                                            <label for="post_title_<?php echo e($language->code); ?>">Title
                                                <small>(<?php echo e($language->code); ?>)</small>
                                                : *</label>
                                            <input type="text" class="form-control post_title" id="post_title_<?php echo e($language->code); ?>" name="<?php echo e($language->code); ?>[title]" value="<?php echo e($trans ? $trans->title :''); ?>" placeholder="Add title" autocomplete="off" <?php echo e($index !== 0 ?: "required"); ?>>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="post_content_<?php echo e($language->code); ?>">Content
                                            <small>(<?php echo e($language->code); ?>)</small>
                                            :</label>
                                        <textarea type="text" class="form-control tinymce_editor" id="post_content_<?php echo e($language->code); ?>" name="<?php echo e($language->code); ?>[content]" rows="10"><?php echo e($trans ? $trans->content :''); ?></textarea>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                    </div>
                </div>



            </div>

            <div class="col-md-4 col-sm-4 col-xs-12">
                <div class="x_panel">
                    <div class="x_title">
                        <h2>Publish</h2>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        <input type="hidden" name="type" value="<?php echo e($post_type); ?>">
                        <input type="hidden" name="post_id" value="<?php echo e($post && $post['id'] ?? $post['id']); ?>">
                        <button type="submit" class="btn btn-success">
                            <?php if(isRoute('admin.post.edit')): ?>
                                Update
                            <?php else: ?>
                                Submit
                            <?php endif; ?>
                        </button>
                    </div>
                </div>

                <?php if(($post_type === \App\Models\Post::TYPE_BLOG) || ( $post && $post['type'] ?? $post['type']   === \App\Models\Post::TYPE_BLOG)): ?>
                    <div class="x_panel">
                        <div class="x_title">
                            <h2>Category</h2>
                            <div class="clearfix"></div>
                        </div>
                        <div class="x_content">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="checkbox">
                                    <label>
                                        <input type="checkbox" class="flat" name="category[]" value="<?php echo e($cat->id); ?>" <?php echo e(isChecked($cat->id, $post['category'])); ?>> <?php echo e($cat->name); ?>

                                    </label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                <?php endif; ?>

                <div class="x_panel">
                    <div class="x_title">
                        <h2>Thumbnail image</h2>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        <label class="post_thumb" for="post_thumb">
                            <img id="preview_thumb" src="<?php echo e(getImageUrl($post && $post['thumb'] ?? $post['thumb'])); ?>" alt="post thumb">
                            <input type="file" class="form-control" id="post_thumb" name="thumb" accept="image/*">
                        </label>
                    </div>
                </div>

            </div>

        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('admin/js/page_post.js')); ?>"></script>

    <?php if(($post_type === \App\Models\Post::TYPE_BLOG) || ( $post && $post['type'] ?? $post['type'] === \App\Models\Post::TYPE_BLOG)): ?>
        <script>
            $("#menu_blog").addClass("active");
            $("#menu_blog .child_menu").show();
        </script>
    <?php else: ?>
        <script>
            $("#menu_pages").addClass("active");
        </script>
    <?php endif; ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /workspace/apps/pricer-new/resources/views/admin/post/post_add.blade.php ENDPATH**/ ?>