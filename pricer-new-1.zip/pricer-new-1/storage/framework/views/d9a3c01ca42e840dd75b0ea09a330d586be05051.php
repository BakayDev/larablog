<?php $__env->startSection('main'); ?>
    <div class="clearfix"></div>
    <div class="row">
        <div class="col-md-12">
            <form method="post" action="<?php echo e(route('admin.setting.create')); ?>" class="form-horizontal" role="form" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <?php if(count(config('setting_fields', [])) ): ?>

                    <?php $__currentLoopData = config('setting_fields'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section => $fields): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="row mb-2">
                            <div class="col-md-12 col-sm-12 ">
                                <div class="dashboard_graph">
                                    <div class="row x_title">
                                        <div class="col-md-6">
                                            <h4>
                                                <i class="<?php echo e(array_get($fields, 'icon', 'glyphicon glyphicon-flash')); ?>"></i>
                                                <?php echo e($fields['title']); ?>

                                                <span class="small"><?php echo e($fields['desc']); ?></span>
                                            </h4>
                                        </div>
                                    </div>
                                    <div class="col-md-7  col-md-offset-2">
                                        <?php $__currentLoopData = $fields['elements']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if ($__env->exists('admin.setting.fields.' . $field['type'] )) echo $__env->make('admin.setting.fields.' . $field['type'] , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <div class="clearfix"></div>
                                </div>
                            </div>
                        </div>
                        <br>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php endif; ?>

                <div class="row m-b-md">
                    <div class="col-md-12">
                        <button class="btn-primary btn">
                            Save Settings
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /workspace/apps/pricer-new/resources/views/admin/setting/setting.blade.php ENDPATH**/ ?>