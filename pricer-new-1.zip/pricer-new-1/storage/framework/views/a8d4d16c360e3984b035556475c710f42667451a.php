<?php
    $page_title_bg = "style='background-image:url(/assets/images/about-01.png)'";
?>
<?php $__env->startSection('main'); ?>
    <main id="main" class="site-main">
        <div class="page-title page-title--small align-left" <?php echo $page_title_bg; ?>>
            <div class="container">
                <div class="page-title__content">
                    <h1 class="page-title__name"><?php echo e($post->title); ?></h1>
                </div>
            </div>
        </div><!-- .page-title -->
        <div class="site-content">
            <div class="container">

                <?php echo $post->content; ?>


            </div>
        </div><!-- .site-content -->
    </main><!-- .site-main -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /workspace/apps/pricer-new/resources/views/frontend/post/page_detail.blade.php ENDPATH**/ ?>