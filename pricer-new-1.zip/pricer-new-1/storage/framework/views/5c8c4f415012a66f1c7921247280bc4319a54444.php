<?php $__env->startSection('main'); ?>
    <div class="clearfix"></div>
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>Dashboard</h2>
                    <div class="clearfix"></div>
                </div>

                <div class="x_content">

                    <div class="dashboard-intro">
                        <div class="dashboard-intro__content">
                            <h2>Welcome to Admin Dashboard.</h2>
                            <p>The Admin Site is an area which only the administrator​ can access. From here you can manage (delete, edit, create) places, categories, cities, country, manage users, review, booking...</p>
                            <p><strong>Staticts:</strong></p>
                            <p>Users: <?php echo e($count_users); ?></p>
                        </div>
                    </div>

                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /workspace/apps/pricer-new/resources/views/admin/dashboard/index.blade.php ENDPATH**/ ?>