<?php $__env->startSection('main'); ?>
    <main id="main" class="site-main">
        <div class="blog-banner">
            <img src="<?php echo e(getImageUrl($post->thumb)); ?>" alt="<?php echo e($post->title); ?>">
            <div class="icon-share">
                <a title="Share" href="#">
                    <svg xmlns="http://www.w3.org/2000/svg" width="27" height="24" viewBox="0 0 27 24">
                        <path fill="#FFF" fill-rule="nonzero" d="M26.256 11.99L15.345.027v7.138h-2.32C5.83 7.164 0 12.996 0 20.19v3.783l1.03-1.13a18.49 18.49 0 0 1 13.658-6.025h.657v7.139L26.256 11.99z"/>
                    </svg>
                </a>
            </div><!-- .place-item__icon -->
        </div><!-- .blog-banner -->
        <div class="blog-content">
            <div class="container">
                <div class="row">
                    <div class="col-lg-9">
                        <div class="blog-left">
                            <ul class="breadcrumbs">
                                <?php $__currentLoopData = $post['categories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><a href="<?php echo e(route('post_list', $cat->slug)); ?>" title="<?php echo e($cat->name); ?>"><?php echo e($cat->name); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul><!-- .breadcrumbs -->
                            <div class="entry-content">
                                <h1><?php echo e($post->title); ?></h1>
                                <ul class="entry-meta">
                                    <li>
                                        <?php echo e(__('by')); ?> <a title="Ben Cobb" href="#"><?php echo e($post['user']['name']); ?></a>
                                    </li>
                                    <li><?php echo e(formatDate($post->created_at, 'd M Y')); ?></li>
                                </ul>
                                <div class="entry-desc">
                                    <?php echo $post->content; ?>

                                </div><!-- .entry-desc -->
                            </div><!-- .entry-content -->
                            <div class="related-post">
                                <h2><?php echo e(__('Related Articles')); ?></h2>
                                <div class="related-grid columns-3">
                                    <?php $__currentLoopData = $related_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $related_post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <article class="hover__box post">
                                            <div class="post__thumb hover__box__thumb">
                                                <a title="<?php echo e($related_post->title); ?>" href="<?php echo e(route('post.detail', [$related_post->slug, $related_post->id])); ?>"><img src="<?php echo e(getImageUrl($related_post->thumb)); ?>" alt="<?php echo e($related_post->title); ?>"></a>
                                            </div>
                                            <div class="post__info">
                                                <ul class="post__category">
                                                    <?php $__currentLoopData = $post['categories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li><a href="<?php echo e(route('post_list', $cat->slug)); ?>" title="<?php echo e($cat->name); ?>"><?php echo e($cat->name); ?></a></li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                                <h3 class="post__title"><a title="<?php echo e($related_post->title); ?>" href="<?php echo e(route('post.detail', [$related_post->slug, $related_post->id])); ?>"><?php echo e($related_post->title); ?></a></h3>
                                            </div>
                                        </article>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>
                            </div><!-- .related-post -->
                        </div><!-- .place__left -->
                    </div>
                    <div class="col-lg-3">
                        <div class="sidebar sidebar--shop sidebar--border">
                            <div class="widget-reservation-mini">
                                <h3><?php echo e(__('Banner Ads')); ?></h3>
                                <a href="https://getgolo.com" class="open-wg btn" target="_blank"><?php echo e(__('View')); ?></a>
                            </div>
                            <aside class="sidebar--shop__item widget widget--ads">
                                <a title="Ads" href="https://getgolo.com" target="_blank"><img src="/assets/images/ads.png" alt=""></a>
                            </aside><!-- .sidebar--shop__item -->
                        </div><!-- .sidebar -->
                    </div>
                </div>
            </div>
        </div><!-- .blog-content -->
    </main><!-- .site-main -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /workspace/apps/pricer-new/resources/views/frontend/post/blog_detail.blade.php ENDPATH**/ ?>