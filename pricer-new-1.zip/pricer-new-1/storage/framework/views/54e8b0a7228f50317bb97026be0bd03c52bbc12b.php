<div class="modal fade" id="modal_add_category" tabindex="-1" role="dialog" aria-labelledby="modal_add_category" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Add category</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
            </div>

            <form action="<?php echo e(route('admin.category.create')); ?>" method="post" data-parsley-validate enctype="multipart/form-data">
                <input type="hidden" id="add_category_method" name="_method" value="POST">
                <?php echo csrf_field(); ?>

                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12">

                            <ul class="nav nav-tabs bar_tabs" role="tablist">
                                <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="nav-item">
                                        <a class="nav-link <?php echo e($index !== 0 ?: "active"); ?>" id="home-tab" data-toggle="tab" href="#language_<?php echo e($language->code); ?>" role="tab" aria-controls="" aria-selected=""><?php echo e($language->name); ?></a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>

                            <div class="tab-content">
                                <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="tab-pane fade show <?php echo e($index !== 0 ?: "active"); ?>" id="language_<?php echo e($language->code); ?>" role="tabpanel" aria-labelledby="home-tab">
                                        <div class="form-group">
                                            <label for="name">Category name
                                                <small>(<?php echo e($language->code); ?>)</small>
                                                : *</label>
                                            <input type="text" class="form-control" name="<?php echo e($language->code); ?>[name]" <?php echo e($index !== 0 ?: "required"); ?>>
                                        </div>

                                        <?php if($type === \App\Models\Category::TYPE_PLACE): ?>
                                            <div class="form-group">
                                                <label for="name">Feature title <small>(<?php echo e($language->code); ?>)</small>:</label>
                                                <input type="text" class="form-control" id="category_feature_title" name="<?php echo e($language->code); ?>[feature_title]">
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                        </div>
                    </div>
                </div>

                <div class="modal-footer">
                    <input type="hidden" id="category_id" name="category_id" value="">
                    <input type="hidden" id="category_type" name="type" value="<?php echo e($type); ?>">
                    <button type="submit" class="btn btn-primary" id="submit_add_category">Add</button>
                    <button class="btn btn-primary" id="submit_edit_category">Save</button>
                    <button class="btn btn-default" data-dismiss="modal">Cancel</button>
                </div>

            </form>

        </div>
    </div>
</div>
<?php /**PATH /workspace/apps/pricer-new/resources/views/admin/category/modal_add_category.blade.php ENDPATH**/ ?>