<div class="form-group <?php echo e($errors->has($field['name']) ? ' has-error' : ''); ?>">
    <label for="<?php echo e($field['name']); ?>"><?php echo e($field['label']); ?></label>
    <?php if(isset($field['data']) && $field['data'] === "image"): ?>
        <p><img src="<?php echo e(asset('uploads/' . \setting($field['name']))); ?>" width="100px" alt="img"></p>
    <?php endif; ?>
    <textarea type="<?php echo e($field['type']); ?>"
              name="<?php echo e($field['name']); ?>"
              class="form-control <?php echo e(array_get( $field, 'class')); ?>"
              id="<?php echo e($field['name']); ?>"
              rows="3"
              placeholder="<?php echo e($field['label']); ?>"><?php echo e(old($field['name'], \setting($field['name']))); ?></textarea>
    <?php if($errors->has($field['name'])): ?>
        <small class="help-block"><?php echo e($errors->first($field['name'])); ?></small>
    <?php endif; ?>
</div><?php /**PATH /workspace/apps/pricer-new/resources/views/admin/setting/fields/textarea.blade.php ENDPATH**/ ?>