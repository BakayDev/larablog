<?php $__env->startSection('main'); ?>
    <div class="page-title">
        <div class="title_left">
            <h3>Reviews</h3>
        </div>
    </div>
    <div class="clearfix"></div>

    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
                <div class="x_title">
                    <div class="row">
                        <div class="col-md-3 form-group">

                        </div>
                    </div>
                    <div class="clearfix"></div>
                </div>

                <div class="x_content">

                    <table class="table table-striped table-bordered golo-datatable">
                        <thead>
                        <tr>
                            <th width="3%">ID</th>
                            <th width="15%">Reviewer</th>
                            <th width="15%">Place name</th>
                            <th>Comment</th>
                            <th width="10%">Star</th>
                            <th width="10%">Status</th>
                            <th width="10%">Action</th>
                        </tr>
                        </thead>
                        <tbody>

                        <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($review->id); ?></td>
                                <td><a><?php echo e($review['user']['name']); ?></a></td>
                                <td>
                                    <?php if(isset($review['place']['slug'])): ?>
                                        <a href="<?php echo e(route('place_detail', $review['place']['slug'])); ?>" target="_blank"><?php echo e($review['place']['name']); ?></a>
                                    <?php else: ?>
                                        <?php echo e($review['place']['name']); ?>

                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($review->comment); ?></td>
                                <td><?php echo e($review->score); ?></td>
                                <td><input type="checkbox" class="js-switch review_status" name="status" data-id="<?php echo e($review->id); ?>" <?php echo e(isChecked(1, $review->status)); ?> /></td>
                                <td>
                                    <form class="d-inline" action="<?php echo e(route('admin_review_delete')); ?>" method="POST">
                                        <?php echo method_field('DELETE'); ?>
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="review_id" value="<?php echo e($review->id); ?>">
                                        <button type="button" class="btn btn-danger btn-xs review_delete">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>


                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('admin/js/page_review.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /workspace/apps/pricer-new/resources/views/admin/review/review_list.blade.php ENDPATH**/ ?>