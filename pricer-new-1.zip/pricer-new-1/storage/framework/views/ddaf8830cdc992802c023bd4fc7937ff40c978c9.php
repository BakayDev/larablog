<?php $__env->startSection('main'); ?>

    <div class="page-title">
        <div class="title_left">
            <h3>Countries</h3>
        </div>
        <div class="title_right">
            <div class="pull-right">
                <button class="btn btn-primary" id="btn_add_country" type="button">+ Add country</button>
            </div>
        </div>
    </div>
    <div class="clearfix"></div>

    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
                <div class="x_content">
                    <table class="table table-striped table-bordered golo-datatable">
                        <thead>
                        <tr>
                            <th>ID</th>
                            <th>Country Name</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($country->id); ?></td>
                                <td><?php echo e($country->name); ?></td>
                                <td>
                                    <button type="button" class="btn btn-warning btn-xs country_edit"
                                            data-id="<?php echo e($country->id); ?>"
                                            data-name="<?php echo e($country->name); ?>"
                                            data-slug="<?php echo e($country->slug); ?>"
                                    >Edit
                                    </button>
                                    <form class="d-inline" action="<?php echo e(route('admin_country_delete',$country->id)); ?>" method="POST">
                                        <?php echo method_field('DELETE'); ?>
                                        <?php echo csrf_field(); ?>
                                        <button type="button" class="btn btn-danger btn-xs country_delete">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>

    <?php echo $__env->make('admin.country.modal_add_country', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('admin/js/page_country.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /workspace/apps/pricer-new/resources/views/admin/country/country_list.blade.php ENDPATH**/ ?>