<div class="form-group <?php echo e($errors->has($field['name']) ? ' has-error' : ''); ?>">
    <div class="checkbox">
        <label>
            <input name="<?php echo e($field['name']); ?>" value="1" type="checkbox" <?php if(old($field['name'], \setting($field['name']))): ?> checked="checked" <?php endif; ?> >
            <?php echo e($field['label']); ?>

        </label>

        <?php if($errors->has($field['name'])): ?> <small class="help-block"><?php echo e($errors->first($field['name'])); ?></small> <?php endif; ?>
    </div>
</div><?php /**PATH /workspace/apps/pricer-new/resources/views/admin/setting/fields/checkbox.blade.php ENDPATH**/ ?>