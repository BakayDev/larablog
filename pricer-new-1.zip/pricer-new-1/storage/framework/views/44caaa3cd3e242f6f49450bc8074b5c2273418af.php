<?php $__env->startSection('main'); ?>
    <div class="page-title">
        <div class="title_left">
            <h3>Language</h3>
        </div>
    </div>
    <div class="clearfix"></div>

    <div class="row">
        <div class="col-md-4 col-sm-4 col-xs-4">
            <div class="x_panel">
                <div class="x_content">

                    <form action="<?php echo e(route('admin.settings.language.status', \App\Models\Language::STATUS_ACTIVE)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('put'); ?>
                        <div class="form-group">
                            <select class="form-control" name="language_id">
                                <?php $__currentLoopData = $language_deactive; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($language->id); ?>"><?php echo e($language->name); ?> (<?php echo e($language->code); ?>)</option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <button type="submit" class="btn btn-success"  onclick="return confirm('Are you sure?');">Active language</button>
                        </div>
                    </form>

                </div>
            </div>
        </div>

        <div class="col-md-8 col-sm-8 col-xs-8">
            <div class="x_panel">
                <div class="x_content">

                    <table class="table">
                        <thead>
                        <tr>
                            <th>Flag</th>
                            <th>Name</th>
                            <th>Default</th>
                            <th>Action</th>
                            <th>Translation</th>
                        </tr>
                        </thead>
                        <tbody>

                        <?php $__currentLoopData = $language_active; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row">
                                    <img src="<?php echo e(flagImageUrl($language->code)); ?>" style="width: 32px" alt="flag">
                                </th>
                                <td><?php echo e($language->name); ?></td>
                                <td>
                                    <input type="checkbox" class="js-switch language_default" name="is_default" data-id="<?php echo e($language->id); ?>" <?php echo e(isChecked(\App\Models\Language::IS_DEFAULT, $language->is_default)); ?> <?php echo e(isDisabled(\App\Models\Language::IS_DEFAULT, $language->is_default)); ?>/>
                                </td>
                                <td>
                                    <form action="<?php echo e(route('admin.settings.language.status', \App\Models\Language::STATUS_DEACTIVE)); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('put'); ?>
                                        <input type="hidden" name="language_id" value="<?php echo e($language->id); ?>">
                                        <button type="submit" class="btn btn-warning btn-sm language_deactive" onclick="return confirm('Are you sure?');" <?php echo e(isDisabled(\App\Models\Language::IS_DEFAULT, $language->is_default)); ?>>Deactive</button>
                                    </form>
                                </td>
                                <td><a class="btn btn-info btn-sm" href="<?php echo e(url('admincp/translations/view/_json')); ?>">Translation</a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('admin/js/page_setting_language.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /workspace/apps/pricer-new/resources/views/admin/setting/setting_language.blade.php ENDPATH**/ ?>